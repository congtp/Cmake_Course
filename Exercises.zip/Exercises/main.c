#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>

#define DEVICE "/dev/driver"

int main() {
    int fd;
    char buffer[80];
    char write_data[] = "Hello from user space!";
    ssize_t bytes_read, bytes_written;

    // Open the device
    fd = open(DEVICE, O_RDWR);
    if (fd < 0) {
        perror("Failed to open the device");
        return 1;
    }

    // Write to the device
    bytes_written = write(fd, write_data, strlen(write_data));
    if (bytes_written < 0) {
        perror("Failed to write to the device");
        close(fd);
        return 1;
    }

    // Seek to the start
    if (lseek(fd, 0, SEEK_SET) < 0) {
        perror("Failed to seek to the start");
        close(fd);
        return 1;
    }

    // Read from the device
    bytes_read = read(fd, buffer, sizeof(buffer) - 1);
    if (bytes_read < 0) {
        perror("Failed to read from the device");
        close(fd);
        return 1;
    }

    // Null-terminate the read data
    buffer[bytes_read] = '\0';

    // Print the read data
    printf("Data read from the device: %s\n", buffer);

    // Close the device
    close(fd);

    return 0;
}
