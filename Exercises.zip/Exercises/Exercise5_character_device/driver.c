#include <linux/module.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include <linux/cdev.h>

#define DEVICE_NAME "driver"
#define BUF_LEN 80

static char device_buffer[BUF_LEN];
static int device_open = 0;
static struct cdev my_cdev;
static dev_t dev_num;

static int my_device_open(struct inode *inode, struct file *file) {
    if (device_open)
        return -EBUSY;
    device_open++;
    return 0;
}

static int device_release(struct inode *inode, struct file *file) {
    device_open--;
    return 0;
}

static ssize_t device_read(struct file *file, char __user *buffer, size_t length, loff_t *offset) {
    if (*offset >= BUF_LEN)
        return 0;
    if (*offset + length > BUF_LEN)
        length = BUF_LEN - *offset;
    if (copy_to_user(buffer, device_buffer + *offset, length))
        return -EFAULT;
    *offset += length;
    return length;
}

static ssize_t device_write(struct file *file, const char __user *buffer, size_t length, loff_t *offset) {
    if (*offset >= BUF_LEN)
        return -EFAULT;
    if (*offset + length > BUF_LEN)
        length = BUF_LEN - *offset;
    if (copy_from_user(device_buffer + *offset, buffer, length))
        return -EFAULT;
    *offset += length;
    return length;
}

static loff_t device_llseek(struct file *file, loff_t offset, int whence) {
    loff_t new_pos = 0;
    switch(whence) {
        case 0: // SEEK_SET
            new_pos = offset;
            break;
        case 1: // SEEK_CUR
            new_pos = file->f_pos + offset;
            break;
        case 2: // SEEK_END
            new_pos = BUF_LEN + offset;
            break;
        default:
            return -EINVAL;
    }
    if (new_pos < 0 || new_pos > BUF_LEN)
        return -EINVAL;
    file->f_pos = new_pos;
    return new_pos;
}

static struct file_operations fops = {
    .owner = THIS_MODULE,
    .read = device_read,
    .write = device_write,
    .open = my_device_open,
    .release = device_release,
    .llseek = device_llseek
};

static int __init simple_char_init(void) {
    int result;
    result = alloc_chrdev_region(&dev_num, 0, 1, DEVICE_NAME);
    if (result < 0) {
        printk(KERN_WARNING "simple_char_dev: can't get major number\n");
        return result;
    }
    cdev_init(&my_cdev, &fops);
    my_cdev.owner = THIS_MODULE;
    result = cdev_add(&my_cdev, dev_num, 1);
    if (result) {
        unregister_chrdev_region(dev_num, 1);
        printk(KERN_WARNING "Error %d adding simple_char_dev", result);
        return result;
    }
    printk(KERN_INFO "simple_char_dev: registered with major number %d\n", MAJOR(dev_num));
    return 0;
}

static void __exit simple_char_exit(void) {
    cdev_del(&my_cdev);
    unregister_chrdev_region(dev_num, 1);
    printk(KERN_INFO "simple_char_dev: unregistered\n");
}

module_init(simple_char_init);
module_exit(simple_char_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Your Name");
MODULE_DESCRIPTION("A Simple Character Device Driver");
