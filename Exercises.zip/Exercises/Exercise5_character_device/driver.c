#include <linux/module.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include <linux/cdev.h>

#define DEVICE_NAME "driver"  // The name of the device file
#define BUF_LEN 80            // Size of the buffer

static char device_buffer[BUF_LEN];  // Buffer to store data
static int device_open = 0;          // Tracks if the device is currently open
static struct cdev my_cdev;          // Character device structure
static dev_t dev_num;                // Device number (major and minor)


// Function called when the device is opened
static int my_device_open(struct inode *inode, struct file *file) {
    if (device_open)  // If the device is already open, return busy
        return -EBUSY;
    device_open++;     // Mark the device as open
    return 0;          // Success
}

// Function called when the device is released/closed
static int device_release(struct inode *inode, struct file *file) {
    device_open--;  // Mark the device as closed
    return 0;       // Success
}

// Function to handle reading from the device
static ssize_t device_read(struct file *file, char __user *buffer, size_t length, loff_t *offset) {
    if (*offset >= BUF_LEN)  // If offset is beyond the buffer, return 0 (EOF)
        return 0;
    if (*offset + length > BUF_LEN)  // Adjust the length to avoid reading beyond buffer
        length = BUF_LEN - *offset;
    
    // Copy data from kernel space (device_buffer) to user space (buffer)
    if (copy_to_user(buffer, device_buffer + *offset, length))
        return -EFAULT;  // Return an error if the copy fails

    *offset += length;  // Update the file offset
    return length;      // Return the number of bytes read
}

// Function to handle writing to the device
static ssize_t device_write(struct file *file, const char __user *buffer, size_t length, loff_t *offset) {
    if (*offset >= BUF_LEN)  // If offset is beyond buffer, return error
        return -EFAULT;
    if (*offset + length > BUF_LEN)  // Adjust length to avoid overflow
        length = BUF_LEN - *offset;
    
    // Copy data from user space (buffer) to kernel space (device_buffer)
    if (copy_from_user(device_buffer + *offset, buffer, length))
        return -EFAULT;  // Return error if copy fails

    *offset += length;  // Update the file offset
    return length;      // Return the number of bytes written
}

// Function to handle seeking (llseek) within the device file
static loff_t device_llseek(struct file *file, loff_t offset, int whence) {
    loff_t new_pos = 0;
    switch (whence) {
        case 0: // SEEK_SET: Set position relative to start of file
            new_pos = offset;
            break;
        case 1: // SEEK_CUR: Set position relative to current file position
            new_pos = file->f_pos + offset;
            break;
        case 2: // SEEK_END: Set position relative to end of file
            new_pos = BUF_LEN + offset;
            break;
        default:
            return -EINVAL;  // Invalid seek
    }
    if (new_pos < 0 || new_pos > BUF_LEN)  // Ensure position is within bounds
        return -EINVAL;
    
    file->f_pos = new_pos;  // Update file position
    return new_pos;         // Return the new position
}

// File operations structure defining the driver's operations
static struct file_operations fops = {
    .owner = THIS_MODULE,
    .read = device_read,
    .write = device_write,
    .open = my_device_open,
    .release = device_release,
    .llseek = device_llseek
};

// Module initialization function (called when the module is loaded)
static int __init simple_char_init(void) {
    int result;

    // Allocate a device number dynamically
    result = alloc_chrdev_region(&dev_num, 0, 1, DEVICE_NAME);
    if (result < 0) {
        printk(KERN_WARNING "simple_char_dev: can't get major number\n");
        return result;
    }

    // Initialize the character device
    cdev_init(&my_cdev, &fops);
    my_cdev.owner = THIS_MODULE;

    // Add the character device to the system
    result = cdev_add(&my_cdev, dev_num, 1);
    if (result) {
        unregister_chrdev_region(dev_num, 1);  // Clean up in case of failure
        printk(KERN_WARNING "Error %d adding simple_char_dev", result);
        return result;
    }

    // Log the major number assigned to the device
    printk(KERN_INFO "simple_char_dev: registered with major number %d\n", MAJOR(dev_num));
    return 0;  // Success
}

// Module cleanup function (called when the module is unloaded)
static void __exit simple_char_exit(void) {
    cdev_del(&my_cdev);  // Remove the character device
    unregister_chrdev_region(dev_num, 1);  // Unregister the device number
    printk(KERN_INFO "simple_char_dev: unregistered\n");
}

// Specify the module's initialization and cleanup functions
module_init(simple_char_init);
module_exit(simple_char_exit);

MODULE_LICENSE("GPL");  // Specify the module's license
MODULE_AUTHOR("Your Name");  // Specify the author's name
MODULE_DESCRIPTION("A Simple Character Device Driver");  // Short description of the module
