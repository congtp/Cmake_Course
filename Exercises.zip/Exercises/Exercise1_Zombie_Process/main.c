#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>  /* library for pid */
#include <sys/wait.h>
#include <unistd.h>

int main()
{
    pid_t child_pid;

    child_pid = fork(); /* Create a child process */

    if(child_pid < 0)
    {
        fprintf(stderr, "Fork failed\n");
        return 1;
    }
    else if (0 == child_pid)
    {
        /* Child process */
        printf("Child process is executing\n");
        exit(0);
    }
    else
    {
        /* Parent process */
        sleep(2); /* Parent process waits for 2 seconds */

        /* 
        - The parent process does not handle the termination
        of the chid process
        - It does not invoke wait() or waitpid() to collect the exit status 
        */

        printf("Parent process is executing\n");
        printf("Zombie process is created\n");
    }

    return 0;
}

