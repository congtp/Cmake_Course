#include <stdio.h>
#include <stdint.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/mman.h>


#define PAGE_SIZE 4096
#define PAGE_MASK (~(PAGE_SIZE-1))

uint64_t get_physical_address(uint64_t virtual_addr)
{
	/* open pagemap file for the current process */
	FILE *pagemap = fopen("/proc/self/pagemap", "rb");
	if(pagemap == NULL)
	{
		perror("Error opening /proc/self/pagemap");
		return -1;
	}

	/* calculate the page index for the virtual address */
	uint64_t page_index = virtual_addr / PAGE_SIZE * sizeof(uint64_t);

	/* seek to the page entry in pagemap */
	if(fseek(pagemap, page_index, SEEK_SET) != 0)
	{
		perror("Error seeking pagemap file");
		fclose(pagemap);
		return -1;
	}

	/* read the page entry */
	uint64_t page_entry;
	if(fread(&page_entry, sizeof(uint64_t), 1, pagemap) != 1)
	{
		perror("Error reading pagemap entry");
                fclose(pagemap);
                return -1;
	}

	fclose(pagemap);

	/* check if the page is present */
	if(!(page_entry & (1ULL << 63)))
	{
		fprintf(stderr, "Page not present in RAM\n");
		return -1;
	}

	/* Extract the physical page number */
	uint64_t physical_page_num = page_entry & ((1ULL << 55) - 1);

	/* calculate the physical address using the physical page number and offset within the page */
	uint64_t physical_addr = (physical_page_num * PAGE_SIZE) + (virtual_addr % PAGE_SIZE);

	return physical_addr;
}

int main(){
	/* declare an integer variable */
	volatile uint32_t my_var = 0x12345678U;

	/* print the virtual address of the variable */
	printf("The virtual address of my_var = %p\n", &my_var);

	/* conver the virtual address to physical address */

	uint64_t virtual_addr = (uint64_t)&my_var;
	uint64_t phys_addr = get_physical_address(virtual_addr);
	if(phys_addr != (uint64_t)-1)
	{
		printf("Physical address of my_var: 0x%lx\n", phys_addr);
	}

	while(1)
	{
		printf("the value of my_var = %x\n", my_var);
		printf("Physical address of my_var: 0x%lx\n", phys_addr);
		sleep(1);
	}

	return 0;
}
