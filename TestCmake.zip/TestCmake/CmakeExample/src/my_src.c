#include "my_src.h"

void my_print(void)
{
    printf("Hello from my_src\n");
}