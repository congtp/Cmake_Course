#ifndef __MY_SRC_H__
#define __MY_SRC_H__

#include <stdio.h>

void my_print(void);

#endif