#include "my_src.h"

int main()
{
    my_print();
    return 0;
}