#include "my_src.h"
#include <nlohmann/json.hpp>
#include <iostream>

int main()
{
    my_print();
    std::cout << "Json lib Version: "
        << NLOHMANN_JSON_VERSION_MAJOR;
    return 0;
}