#ifndef __MY_SRC_H__
#define __MY_SRC_H__

#include <iostream>

void my_print(void);

#endif