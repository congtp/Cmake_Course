# @param1: cmake function name
# @param2: cmake parameters
function(AddSubModule dir)
    # make sure that git is there
    find_package(Git REQUIRED)

    # check if there is a Cmake file in the dir
    if(NOT EXISTS ${dir}/CmakeLists.txt)
        # there is no Cmake file 
        # try to recursively add all the submodule we have in .gitmodules 
        # if the find_package is found, it will set the variable GIT_EXECUTABLE
        # automatically
        # PROJECT_SOURCE_DIR stores the absolute path of our root project
        execute_process(COMMAND ${GIT_EXECUTABLE}
                        submodule update --init --recursive -- ${dir}
                        WORKING_DIRECTORY ${PROJECT_SOURCE_DIR}                
        )

    endif()
    # dir usually is external/submodule/
    add_subdirectory(${dir})
endfunction(AddSubModule)